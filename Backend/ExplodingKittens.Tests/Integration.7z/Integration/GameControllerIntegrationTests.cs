using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using ExplodingKittens.API;
using ExplodingKittens.Application.DTOs;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace ExplodingKittens.Tests.Integration
{
    public class GameControllerIntegrationTests : IClassFixture<CustomWebApplicationFactory<Program>>
    {
        private readonly CustomWebApplicationFactory<Program> _factory;
        private readonly HttpClient _client;
        private readonly string _authToken;

        public GameControllerIntegrationTests(CustomWebApplicationFactory<Program> factory)
        {
            _factory = factory;
            _client = _factory.CreateClient(new WebApplicationFactoryClientOptions
            {
                AllowAutoRedirect = false
            });

            // Get authentication token
            _authToken = GetAuthTokenAsync().Result;

            if (!string.IsNullOrEmpty(_authToken))
            {
                _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authToken);
            }
        }

        [Fact]
        public async Task CreateGame_ReturnsSuccessStatusCode()
        {
            // Arrange
            var createGameDto = new CreateGameDto
            {
                Name = "Test Game",
                HostPlayerId = "testuser"
            };

            var content = new StringContent(
                JsonSerializer.Serialize(createGameDto),
                Encoding.UTF8,
                "application/json");

            // Act
            var response = await _client.PostAsync("/api/games", content);

            // Assert
            response.EnsureSuccessStatusCode();

            var responseContent = await response.Content.ReadAsStringAsync();
            var gameDto = JsonSerializer.Deserialize<GameDto>(
                responseContent,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            Assert.NotNull(gameDto);
            Assert.Equal("Test Game", gameDto.Name);
            Assert.Equal("waiting", gameDto.Status);
            Assert.Contains("testuser", gameDto.Players);
        }

        [Fact]
        public async Task JoinGame_ReturnsSuccessStatusCode()
        {
            // Arrange - Create a game first
            var gameId = await CreateTestGameAsync();

            var content = new StringContent(
                JsonSerializer.Serialize("testuser2"),
                Encoding.UTF8,
                "application/json");

            // Act
            var response = await _client.PostAsync($"/api/games/{gameId}/join", content);

            // Assert
            response.EnsureSuccessStatusCode();

            // Get the game to verify the player was added
            var getResponse = await _client.GetAsync($"/api/games/{gameId}");
            getResponse.EnsureSuccessStatusCode();

            var responseContent = await getResponse.Content.ReadAsStringAsync();
            var gameDto = JsonSerializer.Deserialize<GameDto>(
                responseContent,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            Assert.NotNull(gameDto);
            Assert.Contains("testuser", gameDto.Players);
            Assert.Contains("testuser2", gameDto.Players);
        }

        [Fact]
        public async Task StartGame_WithEnoughPlayers_ReturnsSuccessStatusCode()
        {
            // Arrange - Create a game with two players
            var gameId = await CreateTestGameWithPlayersAsync(2);

            // Act
            var response = await _client.PostAsync($"/api/games/{gameId}/start", null);

            // Assert
            response.EnsureSuccessStatusCode();

            // Get the game to verify it started
            var getResponse = await _client.GetAsync($"/api/games/{gameId}");
            getResponse.EnsureSuccessStatusCode();

            var responseContent = await getResponse.Content.ReadAsStringAsync();
            var gameDto = JsonSerializer.Deserialize<GameDto>(
                responseContent,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            Assert.NotNull(gameDto);
            Assert.Equal("in_progress", gameDto.Status);
            Assert.NotNull(gameDto.CurrentPlayerId);
            Assert.Equal(1, gameDto.TurnNumber);
        }

        [Fact]
        public async Task StartGame_WithoutEnoughPlayers_ReturnsBadRequest()
        {
            // Arrange - Create a game with just one player (not enough)
            var gameId = await CreateTestGameAsync();

            // Act
            var response = await _client.PostAsync($"/api/games/{gameId}/start", null);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        }

        private async Task<string> GetAuthTokenAsync()
        {
            // This is a simplified authentication for testing
            var loginDto = new LoginDto
            {
                Username = "testuser",
                Password = "testpassword"
            };

            var content = new StringContent(
                JsonSerializer.Serialize(loginDto),
                Encoding.UTF8,
                "application/json");

            var response = await _client.PostAsync("/api/auth/login", content);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var responseObject = JsonSerializer.Deserialize<JsonElement>(responseContent);

                if (responseObject.TryGetProperty("token", out var tokenElement))
                {
                    return tokenElement.GetString();
                }
            }

            // For testing, we could return a mock token or throw an exception
            return "mock_token_for_testing";
        }

        private async Task<string> CreateTestGameAsync()
        {
            var createGameDto = new CreateGameDto
            {
                Name = "Test Game",
                HostPlayerId = "testuser"
            };

            var content = new StringContent(
                JsonSerializer.Serialize(createGameDto),
                Encoding.UTF8,
                "application/json");

            var response = await _client.PostAsync("/api/games", content);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var gameDto = JsonSerializer.Deserialize<GameDto>(
                    responseContent,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                return gameDto.Id;
            }

            return null;
        }

        private async Task<string> CreateTestGameWithPlayersAsync(int numPlayers)
        {
            var gameId = await CreateTestGameAsync();

            for (int i = 2; i <= numPlayers; i++)
            {
                var content = new StringContent(
                    JsonSerializer.Serialize($"testuser{i}"),
                    Encoding.UTF8,
                    "application/json");

                await _client.PostAsync($"/api/games/{gameId}/join", content);
            }

            return gameId;
        }
    }

    public class CustomWebApplicationFactory<TStartup> : WebApplicationFactory<TStartup> where TStartup : class
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureServices(services =>
            {
                // Replace services with test mocks here
                // For example, replace the database context with an in-memory database
            });
        }
    }
}