using System;
using System.Linq;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using ExplodingKittens.Infrastructure.Data.Context;
using Microsoft.Extensions.Configuration;

namespace ExplodingKittens.Tests.Integration
{
    public class CustomWebApplicationFactory<TProgram> : WebApplicationFactory<TProgram> where TProgram : class
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureAppConfiguration((context, config) =>
            {
                // Add test configuration settings
                config.AddInMemoryCollection(new Dictionary<string, string>
                {
                    {"MongoDbSettings:ConnectionString", "mongodb://localhost:27017"},
                    {"MongoDbSettings:DatabaseName", "ExplodingKittensTest"},
                    {"JwtSettings:Secret", "TestSecretKeyThatIsAtLeast32CharactersLong"},
                    {"JwtSettings:Issuer", "TestIssuer"},
                    {"JwtSettings:Audience", "TestAudience"},
                    {"JwtSettings:ExpirationInMinutes", "60"}
                });
            });

            builder.ConfigureServices(services =>
            {
                // Find the real MongoDbContext registration
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(MongoDbContext));

                if (descriptor != null)
                {
                    // Remove the real registration
                    services.Remove(descriptor);

                    // Add the test version
                    services.AddSingleton<MongoDbContext>(sp =>
                    {
                        // Configure a test MongoDB context that uses a test database
                        var configuration = sp.GetRequiredService<IConfiguration>();
                        var settings = new ExplodingKittens.Infrastructure.Data.Configurations.MongoDbSettings
                        {
                            ConnectionString = configuration["MongoDbSettings:ConnectionString"],
                            DatabaseName = configuration["MongoDbSettings:DatabaseName"]
                        };

                        return new MongoDbContext(Microsoft.Extensions.Options.Options.Create(settings));
                    });
                }

                // Add other test services as needed
            });
        }
    }
}