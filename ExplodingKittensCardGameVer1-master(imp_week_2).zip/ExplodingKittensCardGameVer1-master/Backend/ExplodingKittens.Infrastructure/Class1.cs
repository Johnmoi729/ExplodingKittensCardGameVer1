﻿namespace ExplodingKittens.Infrastructure;

public class Class1
{

}
