﻿namespace ExplodingKittens.Domain;

public class Class1
{

}
