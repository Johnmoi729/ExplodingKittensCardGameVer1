﻿namespace ExplodingKittens.Application;

public class Class1
{

}
